<?php

namespace Admin\Controllers;

class DashboardController {
    public function index() {
        echo "Welcome to the Admin Dashboard!";
    }
}
