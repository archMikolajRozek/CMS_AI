<?php

namespace Admin\Controllers;

use Admin\Models\News;

class NewsController {
    public function index() {
        $news = News::getAll();
        require __DIR__ . '/../views/news/index.php';
    }

    public function create() {
        require __DIR__ . '/../views/news/create.php';
    }

    public function edit($id) {
        $news = News::find($id);
        require __DIR__ . '/../views/news/edit.php';
    }

    public function delete($id) {
        News::delete($id);
        header('Location: /admin/news');
        exit;
    }
}
