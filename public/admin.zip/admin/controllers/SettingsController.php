<?php

namespace Admin\Controllers;

use Admin\Models\Module;

class SettingsController {
    /**
     * Wyświetlanie listy modułów.
     */
    public function modules() {
        $modules = Module::getAll();
        require __DIR__ . '/../views/settings/modules.php';
    }

    /**
     * Obsługa akcji na module: aktywacja, dezaktywacja, zamrażanie, usuwanie.
     */
    public function toggleModule($id, $action) {
        $module = Module::find($id);

        if (!$module) {
            die('Module not found.');
        }

        if ($module['is_builtin']) {
            die('Cannot modify a built-in module.');
        }

        switch ($action) {
            case 'activate':
                $module->activate();
                break;
            case 'deactivate':
                $module->deactivate();
                break;
            case 'freeze':
                $module->freeze();
                break;
            case 'delete':
                $module->delete();
                break;
            default:
                die('Invalid action.');
        }

        header('Location: /admin/settings/modules');
        exit;
    }

    /**
     * Dodawanie nowego modułu.
     */
    public function addModule() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name']);
            $description = trim($_POST['description']);

            if (empty($name) || empty($description)) {
                die('Name and description are required.');
            }

            Module::create([
                'name' => $name,
                'description' => $description,
                'status' => 'inactive',
                'is_builtin' => 0
            ]);

            header('Location: /admin/settings/modules');
            exit;
        }

        require __DIR__ . '/../views/settings/add_module.php';
    }
}
