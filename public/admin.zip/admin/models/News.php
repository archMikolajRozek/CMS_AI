<?php

namespace Admin\Models;

use App\Database;

class News {
    public static function getAll() {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT * FROM news");
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    public static function find($id) {
        $db = Database::getConnection();
        $stmt = $db->prepare("SELECT * FROM news WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(\PDO::FETCH_ASSOC);
    }

    public static function create($data) {
        $db = Database::getConnection();
        $stmt = $db->prepare("INSERT INTO news (title, content, created_at) VALUES (?, ?, ?)");
        return $stmt->execute([$data['title'], $data['content'], date('Y-m-d H:i:s')]);
    }

    public static function update($id, $data) {
        $db = Database::getConnection();
        $stmt = $db->prepare("UPDATE news SET title = ?, content = ? WHERE id = ?");
        return $stmt->execute([$data['title'], $data['content'], $id]);
    }

    public static function delete($id) {
        $db = Database::getConnection();
        $stmt = $db->prepare("DELETE FROM news WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
