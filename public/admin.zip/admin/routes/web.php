<?php

use Admin\Controllers\DashboardController;
use Admin\Controllers\NewsController;
use Admin\Controllers\UsersController;
use Admin\Controllers\GalleryController;
use Admin\Controllers\SettingsController;

return [
    // Dashboard
    '/admin' => [DashboardController::class, 'index'],

    // Aktualności
    '/admin/news' => [NewsController::class, 'index'],
    '/admin/news/create' => [NewsController::class, 'create'],
    '/admin/news/edit' => [NewsController::class, 'edit'],
    '/admin/news/delete' => [NewsController::class, 'delete'],

    // Użytkownicy
    '/admin/users' => [UsersController::class, 'index'],
    '/admin/users/create' => [UsersController::class, 'create'],
    '/admin/users/edit' => [UsersController::class, 'edit'],
    '/admin/users/delete' => [UsersController::class, 'delete'],

    // Galeria
    '/admin/gallery' => [GalleryController::class, 'index'],
    '/admin/gallery/create' => [GalleryController::class, 'create'],
    '/admin/gallery/edit' => [GalleryController::class, 'edit'],
    '/admin/gallery/delete' => [GalleryController::class, 'delete'],

    // Ustawienia: Moduły
    '/admin/settings/modules' => [SettingsController::class, 'modules'],
    '/admin/settings/modules/add' => [SettingsController::class, 'addModule'],
    '/admin/settings/modules/{id}/{action}' => [SettingsController::class, 'toggleModule'],
];
