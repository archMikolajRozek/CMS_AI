<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <h1>Welcome to the Admin Dashboard</h1>
    <p>This is the main panel where you can manage the system.</p>
    <ul>
        <li><a href="/news">Manage News</a></li>
        <li><a href="/users">Manage Users</a></li>
        <li><a href="/gallery">Manage Gallery</a></li>
    </ul>
</body>
</html>
