<!DOCTYPE html>
<html>
<head>
    <title>Manage Gallery</title>
</head>
<body>
    <h1>Gallery List</h1>
    <a href="/gallery/create">Create New Gallery</a>
    <ul>
        <!-- Mock data, replace with PHP loop -->
        <li>Gallery Item 1 - <a href="/gallery/edit?id=1">Edit</a> | <a href="/gallery/delete?id=1">Delete</a></li>
        <li>Gallery Item 2 - <a href="/gallery/edit?id=2">Edit</a> | <a href="/gallery/delete?id=2">Delete</a></li>
    </ul>
</body>
</html>
