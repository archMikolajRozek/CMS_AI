<!DOCTYPE html>
<html>
<head>
    <title>Create News</title>
</head>
<body>
    <h1>Create News</h1>
    <form method="POST" action="/news/create">
        <label>Title: <input type="text" name="title" required></label><br>
        <label>Content: <textarea name="content" required></textarea></label><br>
        <button type="submit">Save</button>
    </form>
</body>
</html>
