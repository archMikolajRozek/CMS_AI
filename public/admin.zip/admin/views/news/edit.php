<!DOCTYPE html>
<html>
<head>
    <title>Edit News</title>
</head>
<body>
    <h1>Edit News</h1>
    <form method="POST" action="/news/edit?id=<?php echo $_GET['id']; ?>">
        <label>Title: <input type="text" name="title" value="Mock Title" required></label><br>
        <label>Content: <textarea name="content" required>Mock Content</textarea></label><br>
        <button type="submit">Update</button>
    </form>
</body>
</html>
