<!DOCTYPE html>
<html>
<head>
    <title>Manage News</title>
</head>
<body>
    <h1>News List</h1>
    <a href="/news/create">Create New News</a>
    <ul>
        <!-- Mock data, replace with PHP loop -->
        <li>News Title 1 - <a href="/news/edit?id=1">Edit</a> | <a href="/news/delete?id=1">Delete</a></li>
        <li>News Title 2 - <a href="/news/edit?id=2">Edit</a> | <a href="/news/delete?id=2">Delete</a></li>
    </ul>
</body>
</html>
