<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista Modułów</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        .action-buttons a {
            text-decoration: none;
            padding: 5px 10px;
            margin: 0 5px;
            border-radius: 5px;
            border: 1px solid #007bff;
            background-color: #007bff;
            color: white;
            font-size: 14px;
        }
        .action-buttons a.disabled {
            background-color: #ccc;
            border-color: #ccc;
            pointer-events: none;
        }
    </style>
</head>
<body>
    <h1>Lista Modułów</h1>
    <table>
        <thead>
            <tr>
                <th>Nazwa</th>
                <th>Opis</th>
                <th>Status</th>
                <th>Wbudowany</th>
                <th>Akcje</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($modules as $module): ?>
                <tr>
                    <td><?= htmlspecialchars($module['name']); ?></td>
                    <td><?= htmlspecialchars($module['description']); ?></td>
                    <td><?= htmlspecialchars($module['status']); ?></td>
                    <td><?= $module['is_builtin'] ? 'Tak' : 'Nie'; ?></td>
                    <td class="action-buttons">
                        <?php if ($module['is_builtin']): ?>
                            <a class="disabled">Aktywne</a>
                        <?php else: ?>
                            <?php if ($module['status'] === 'active'): ?>
                                <a href="/admin/settings/modules/<?= $module['id']; ?>/deactivate">Dezaktywuj</a>
                                <a href="/admin/settings/modules/<?= $module['id']; ?>/freeze">Zamroź</a>
                            <?php elseif ($module['status'] === 'inactive'): ?>
                                <a href="/admin/settings/modules/<?= $module['id']; ?>/activate">Aktywuj</a>
                            <?php elseif ($module['status'] === 'frozen'): ?>
                                <a href="/admin/settings/modules/<?= $module['id']; ?>/activate">Odblokuj</a>
                            <?php endif; ?>
                            <a href="/admin/settings/modules/<?= $module['id']; ?>/delete">Usuń</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
