<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
</head>
<body>
    <h1>Users List</h1>
    <a href="/users/create">Create New User</a>
    <ul>
        <!-- Mock data, replace with PHP loop -->
        <li>User 1 - <a href="/users/edit?id=1">Edit</a> | <a href="/users/delete?id=1">Delete</a></li>
        <li>User 2 - <a href="/users/edit?id=2">Edit</a> | <a href="/users/delete?id=2">Delete</a></li>
    </ul>
</body>
</html>
